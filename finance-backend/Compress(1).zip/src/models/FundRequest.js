const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../config/db');

const FUND_FLOW_STAGES = [
    'FUND_APPROVED',
    'FUND_RELEASED',
    'BILLS_UPLOADED',
    'CHEQUE_RELEASED',
    'AMOUNT_DISBURSED',
    'UTILIZATION_COMPLETED',
    'SETTLEMENT_CLOSED'
];

const VALID_STATUSES = [
    'PENDING',
    'PENDING_APPROVAL',
    'APPROVED',
    'PARTIALLY_DISBURSED',
    'COMPLETED',
    'DISBURSED',
    'REJECTED',
    'CANCELLED'
];

class FundRequest extends Model {
    async advanceStage(nextStage, updatedBy, remarks) {
        const currentIndex = FUND_FLOW_STAGES.indexOf(this.currentStage);
        const nextIndex = FUND_FLOW_STAGES.indexOf(nextStage);
        
        if (nextIndex <= currentIndex) {
            throw new Error(`Cannot move from ${this.currentStage} to ${nextStage}. Only forward movement is allowed.`);
        }
        
        const prevStage = this.currentStage;
        this.currentStage = nextStage;
        
        const newEntry = {
            stage: nextStage,
            prevStage,
            updatedBy: updatedBy._id,
            updatedByName: updatedBy.name,
            timestamp: new Date(),
            remarks
        };

        // Audit DB should be used for tracking history now
        
        // Auto-update chequeStatus
        if (nextStage === 'CHEQUE_RELEASED') this.chequeStatus = 'Approved';
        if (nextStage === 'AMOUNT_DISBURSED') this.chequeStatus = 'Disbursed';
        
        return this.save();
    }
}

FundRequest.init({
    _id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
    },
    projectTitle: {
        type: DataTypes.STRING,
        allowNull: false
    },
    organizationId: {
        type: DataTypes.STRING,
        allowNull: false,
        defaultValue: 'ORG_1',
    },
    projectId: {
        type: DataTypes.UUID,
        allowNull: true
    },
    faculty: {
        type: DataTypes.STRING,
        allowNull: false
    },
    userId: {
        type: DataTypes.UUID,
        allowNull: true
    },
    facultyId: {
        type: DataTypes.UUID,
        allowNull: true
    },
    requestedAmount: {
        type: DataTypes.FLOAT,
        allowNull: false,
        validate: { min: 1 }
    },
    installmentNumber: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 1,
        comment: 'Sequential installment number per project (1, 2, 3…)'
    },
    type: {
        type: DataTypes.STRING,
        defaultValue: 'INSTALLMENT',
        allowNull: false
    },
    purpose: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    status: {
        type: DataTypes.STRING,
        defaultValue: 'PENDING',
        validate: {
            isIn: {
                args: [VALID_STATUSES],
                msg: `Status must be one of: ${VALID_STATUSES.join(', ')}`
            }
        }
    },
    currentStage: {
        type: DataTypes.ENUM(...FUND_FLOW_STAGES),
        allowNull: true,
        defaultValue: null,
    },
    chequeStatus: {
        type: DataTypes.ENUM('Pending', 'Approved', 'Disbursed'),
        defaultValue: 'Pending'
    },
    department: {
        type: DataTypes.STRING,
        allowNull: false
    },
    centre: {
        type: DataTypes.STRING, // Keep for backward compatibility/quick display
        allowNull: true
    },
    centreId: {
        type: DataTypes.UUID,
        allowNull: true
    },
    source: {
        type: DataTypes.ENUM('PFMS', 'INSTITUTIONAL', 'OTHERS'),
        allowNull: false
    },
    // CEER Budget Granularity details:
    majorEquipments: { type: DataTypes.FLOAT, defaultValue: 0 },
    minorEquipments: { type: DataTypes.FLOAT, defaultValue: 0 },
    consumables: { type: DataTypes.FLOAT, defaultValue: 0 },
    services: { type: DataTypes.FLOAT, defaultValue: 0 },
    amc: { type: DataTypes.FLOAT, defaultValue: 0 },
    documents: {
        type: DataTypes.JSON,
        defaultValue: []
    },

}, { 
    sequelize, 
    modelName: 'FundRequest',
    timestamps: true,
    indexes: [
        { fields: ['status'] },
        { fields: ['currentStage'] },
        { fields: ['facultyId'] }
    ]
});


module.exports = { FundRequest, FUND_FLOW_STAGES, VALID_STATUSES };
