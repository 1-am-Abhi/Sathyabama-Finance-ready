module.exports = require('./ResearchCenter');
