const logger = require('../utils/logger');
const asyncHandler = require('../utils/asyncHandler');
const { Notification } = require('../models');
const NotificationService = require('../services/notificationService');

const normalizeType = (type = 'INFO') => String(type).trim().toUpperCase();

const getAuthUserId = (req) => String(req.user?.id || req.user?._id || '');

const canAccessUserNotifications = (req, userId) =>
    String(userId || '') === getAuthUserId(req) ||
    String(req.user?.role || '').toUpperCase() === 'ADMIN';

const createNotification = asyncHandler(async (req, res) => {
    const { title, message, type, role, targetUserId, relatedId, actionUrl } = req.body;
    logger.info(`[NotificationController] Request to create notification:`, { title, role, targetUserId });

    if (!targetUserId && role) {
        logger.info(`[NotificationController] Broadcasting to role: ${role}`);
        let notifications;
        try {
            notifications = await NotificationService.notifyRole(
                role,
                title || 'Notification',
                message,
                normalizeType(type),
                relatedId || actionUrl || null
            );
        } catch (error) {
            if (error.message.includes('No users found')) {
                return res.status(404).json({ success: false, message: 'No users found for role' });
            }
            throw error;
        }

        if (!notifications || notifications.length === 0) {
            return res.status(404).json({ success: false, message: 'No users found for role' });
        }

        return res.status(201).json({ success: true, data: notifications });
    }

    const target = targetUserId || req.user?.id || req.user?._id;
    logger.info(`[NotificationController] Creating for single user: ${target}`);
    
    const notification = await NotificationService.create(
        target,
        title || 'Notification',
        message,
        normalizeType(type),
        relatedId || actionUrl || null
    );

    res.status(201).json({ success: true, data: notification || {} });
});

const getNotifications = asyncHandler(async (req, res) => {
    const userId = req.params.userId || req.user.id || req.user._id;

    if (!canAccessUserNotifications(req, userId)) {
        return res.status(403).json({ success: false, message: 'Unauthorized' });
    }

    const whereClause = { userId };
    if (req.query.isRead !== undefined) {
        whereClause.isRead = req.query.isRead === 'true';
    }

    // TASK 5 — OPTIMIZE NOTIFICATION QUERY
    const notifications = await Notification.findAll({
        where: whereClause,
        order: [['createdAt', 'DESC']],
        limit: Number(req.query.limit) || 50
    });

    res.status(200).json({ success: true, data: notifications || [] });
});

const markAsRead = asyncHandler(async (req, res) => {
    const { id } = req.params;
    const notification = await Notification.findByPk(id);

    if (!notification) {
        return res.status(404).json({ success: false, message: 'Notification not found' });
    }

    if (!canAccessUserNotifications(req, notification.userId)) {
        return res.status(403).json({ success: false, message: 'Unauthorized' });
    }

    await notification.update({ isRead: true });

    res.status(200).json({ success: true, message: 'Marked as read', data: notification || {} });
});

const markAllAsRead = asyncHandler(async (req, res) => {
    const userId = req.params.userId || req.user.id || req.user._id;

    if (!canAccessUserNotifications(req, userId)) {
        return res.status(403).json({ success: false, message: 'Unauthorized' });
    }

    await Notification.update(
        { isRead: true },
        {
            where: {
                userId,
                isRead: false
            }
        }
    );

    res.status(200).json({ success: true, message: 'All notifications marked as read' });
});

module.exports = {
    createNotification,
    getNotifications,
    markAsRead,
    markAllAsRead
};

